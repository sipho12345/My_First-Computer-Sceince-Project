import sys
from socket import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from GameClient import *
from PyQt5.QtCore import *
from LoopThread import LoopThread
from GameServer import GameServer
from PyQt5.QtMultimedia import *
from gtts import gTTS
import os
#from OXOTextClient import * #for testing purposes


class OXO_Client(QWidget, GameClient):
	def __init__(self, parent=None):
		GameClient.__init__(self)
		QWidget.__init__(self, parent)
		self.setGeometry(700, 600, 650, 450)
		self.setWindowTitle("OXO Game")
		self.setToolTip('OXO Game')
		
		#Icon
		self.setWindowIcon(QIcon("icon.png"))
		
		 #Default score values
		self.Xscr = 0  
		self.Oscr = 0
		
		#Text to Voice/Speech conversion for this to work install gTTS using "pip install gTTS" in the command prompt
		mytext="welcome to oxo game created by Lesego and Sipho both players must connect to a server before playing"
		language ="en"
		
		self.voice = gTTS(text=mytext, lang=language, slow=False)       
		
		self.voice.save("welcome.mp3")
		os.system("welcome.mp3")
		
		
		#Background
		back_pic = QPalette()
		back_pic.setBrush(QPalette.Background,QBrush(QPixmap("background.jpg"))) 
		self.setPalette(back_pic)         
		self.setPalette(back_pic)		
		
		 # Labels
		server_label = QLabel('Server:')
		server_label.setFont(QFont("Arial",15,2))
		server_label.setStyleSheet("QLabel{color:white;font-weight:bold;}")
		
		shape_label = QLabel('Shape:')
		shape_label.setFont(QFont("Arial",15,2))
		shape_label.setStyleSheet("QLabel{color:white;font-weight:bold;}")
		
		mfs = QLabel('Message from the Server:')
		mfs.setFont(QFont("Arial",13,2))
		mfs.setStyleSheet("QLabel{color:white;font-weight:bold;}")
		
		game_label = QLabel('Game Board:')
		game_label.setFont(QFont("Arial",13,2))
		game_label.setStyleSheet("QLabel{color:white;font-weight:bold;}")
		
		score = QLabel("Your score is:")
		score.setFont(QFont("Arial",13,2))
		score.setStyleSheet("QLabel{color:white;font-weight:bold;}")
		
		
		#Pictures
		self.cross = QPixmap("cross.gif")
		self.nought = QPixmap("nought.gif")
		
		
		#Edits
		self.server_edit = QLineEdit('localhost')
		self.mfs_edit = QTextEdit()
		self.score_edit = QLineEdit()
		self.mfs_edit.move(750,450)
		
		#Buttons
		self.ng_button = QPushButton("New Game")		
		self.ng_button.setToolTip("click to start a new game")
		self.quit = QPushButton("Quit")
		self.quit.setToolTip("Click to end game")
		self.connect = QPushButton("Connect")
		self.connect.setToolTip("Click to connect to the game")
		
		#Default Picture Shape 
		pixmap = QPixmap("blank.gif")
		self.pic_label = QLabel()
		self.pic_label.setPixmap(pixmap)		
		
		# Board Buttons
		self.b0 = QPushButton()
		self.b1 = QPushButton()
		self.b2 = QPushButton()
		self.b3 = QPushButton()
		self.b4 = QPushButton()
		self.b5 = QPushButton()
		self.b6 = QPushButton()
		self.b7 = QPushButton()
		self.b8 = QPushButton()
		
		self.b0.setFixedHeight(60)
		self.b0.setFixedWidth(60)
	       
		self.b1.setFixedHeight(60)
		self.b1.setFixedWidth(60)
	
		self.b2.setFixedHeight(60)
		self.b2.setFixedWidth(60)        
	
		self.b3.setFixedHeight(60)
		self.b3.setFixedWidth(60)
		
		self.b4.setFixedHeight(60)
		self.b4.setFixedWidth(60)        
		
		self.b5.setFixedHeight(60)
		self.b5.setFixedWidth(60)        
		
		self.b6.setFixedHeight(60)
		self.b6.setFixedWidth(60)
		
		self.b7.setFixedHeight(60)
		self.b7.setFixedWidth(60)        
		
		self.b8.setFixedHeight(60)
		self.b8.setFixedWidth(60) 		
		
		#Grid Layout
		grid = QGridLayout() 
		grid.addWidget(self.b0,0,0)
		grid.addWidget(self.b1,0,1)
		grid.addWidget(self.b2,0,2)
		grid.addWidget(self.b3,1,0)
		grid.addWidget(self.b4,1,1)
		grid.addWidget(self.b5,1,2)
		grid.addWidget(self.b6,2,0)
		grid.addWidget(self.b7,2,1)
		grid.addWidget(self.b8,2,2)
		self.grid_widget = QWidget()
		self.grid_widget.setLayout(grid)
		self.grid_widget.setToolTip("Click any <strong>button/strong> to make a move")
		
		# create layout for username and password
		grid = QGridLayout()           
		grid.addWidget(server_label,0,0) 
		grid.addWidget(self.server_edit,0,1)   
		grid.addWidget(self.connect,1,1)
		grid.addWidget(shape_label,2,0)
		grid.addWidget(mfs,3,0)
		grid.addWidget(self.mfs_edit,4,0,3,1)
		grid.addWidget(self.score_edit,8,2)
		grid.addWidget(score,8,1)
		grid.addWidget(game_label,3,1)
		grid.addWidget(self.ng_button,9,1)
		grid.addWidget(self.quit,9,2)
		grid.addWidget(self.pic_label,2,1)
		grid.addWidget(self.grid_widget,4,1)
		
		#Game Play Signals
		grid_widget = QWidget()
		self.setLayout(grid)
		self.loop_thread=LoopThread()
		self.loop_thread.signal.connect(self.thread_slot)
		self.ng_button.clicked.connect(self.new_game_clicked)
		self.quit.clicked.connect(self.button_clicked)
		self.connect.clicked.connect(self.connect_to_server)
		self.b0.clicked.connect(self.b0_clicked)
		self.b1.clicked.connect(self.b1_clicked)
		self.b2.clicked.connect(self.b2_clicked)
		self.b3.clicked.connect(self.b3_clicked)
		self.b4.clicked.connect(self.b4_clicked)
		self.b5.clicked.connect(self.b5_clicked)
		self.b6.clicked.connect(self.b6_clicked)
		self.b7.clicked.connect(self.b7_clicked)
		self.b8.clicked.connect(self.b8_clicked)		
		
		
		self.positions = ["0","1","2","3","4","5","6","7","8"]
		
		
	# Functions when the user interact with board	
	def b0_clicked(self):
		try:
			self.loop_thread.send_message(self.positions[0])
		except Exception as r:
			print(r)
		    
	def b1_clicked(self):
		try: 
			self.loop_thread.send_message(self.positions[1])
		except Exception as r:
			print(r)
	    
	def b2_clicked(self):
		try:
			self.loop_thread.send_message(self.positions[2])
		except Exception as r:
			print(r)
		       
	def b3_clicked(self):
		try:
			self.loop_thread.send_message(self.positions[3])
		except Exception as r:
			print(r)
	
	def b4_clicked(self):
		try:      
			self.loop_thread.send_message(self.positions[4])
		except Exception as r:
			print(r)
		    
	def b5_clicked(self):
		try:
			self.loop_thread.send_message(self.positions[5])
		except Exception as r:
			print(r)
		    
	def b6_clicked(self):
		try:           
			self.loop_thread.send_message(self.positions[6])
		except Exception as r:
			print(r)
	
	def b7_clicked(self):
		try:           
			self.loop_thread.send_message(self.positions[7])
		except Exception as r:
			print(r)
	def b8_clicked(self):
		try:
			self.loop_thread.send_message(self.positions[8])
		except Exception as r:
			print(r)	

	# Handles message from and to a server		
	def handle_gui(self,msg):                                         
		if msg == "new game,O":
			self.score_edit.setText(str(self.Oscr)) 
			self.icon = self.nought
			self.pic_label.setPixmap(self.icon)
			self.mfs_edit.append(msg[:8] + "\n")
		elif msg == "new game,X":
			self.score_edit.setText(str(self.Xscr))
			self.icon = self.cross
			self.pic_label.setPixmap(self.icon)
			self.mfs_edit.append(msg[:8] + "\n")      
			
		elif msg == "your move": 
			#print("your move")   
			self.mfs_edit.append(msg)
			self.ng_button.setEnabled(False)                        # Disables the new game button
			self.connect.setEnabled(False)                          # Disable the connect button
			self.b0.setEnabled(True)                                # Disable the board while the other player is playing
			self.b1.setEnabled(True)
			self.b2.setEnabled(True)
			self.b3.setEnabled(True)
			self.b4.setEnabled(True)
			self.b5.setEnabled(True)
			self.b6.setEnabled(True)
			self.b7.setEnabled(True)
			self.b8.setEnabled(True)			
			
		elif msg == "opponents move":
			#print("opponents move")
			self.mfs_edit.append(msg)
			self.ng_button.setEnabled(False)
			self.connect.setEnabled(False)
			self.b0.setEnabled(False)
			self.b1.setEnabled(False)
			self.b2.setEnabled(False)
			self.b3.setEnabled(False)
			self.b4.setEnabled(False)
			self.b5.setEnabled(False)
			self.b6.setEnabled(False)
			self.b7.setEnabled(False)
			self.b8.setEnabled(False)
			
		elif msg == "invalid move":
			self.mfs_edit.append(msg)
		elif msg[:9] == "game over":
			self.mfs_edit.append(msg[:9])
			if msg[-1] == "T":
				self.mfs_edit.append("It's a tie!")
			elif msg[-1] == "X":
				self.Xscr +=1
				#print(self.Xscr)                               # Keeps track of the score
			elif msg[-1] == "O":
				self.Oscr +=1
				#print(self.Oscr)
			else:
				self.mfs_edit.append("Shape "+str(msg[-1])+" Won!")
			
		elif msg == "play again":
			#print(msg)
			self.ng_button.setEnabled(True)
			self.mfs_edit.append("Press <New game> to play again and \nPress <Quit> to end game.")
			
		elif msg == "exit game":
			self.mfs_edit.append(msg)
		
		elif msg[:10] == "valid move":
			if msg[-3] == "O":
				#self.msg_edit.append(msg[:10])
				position = msg[-1]
				if position == "0":
					self.b0.setIcon(QIcon(self.nought))
					self.b0.setIconSize(QSize(55,50))
				elif position == "1":
					self.b1.setIcon(QIcon(self.nought))
					self.b1.setIconSize(QSize(55,50))
				elif position == "2":
					self.b2.setIcon(QIcon(self.nought))
					self.b2.setIconSize(QSize(55,50))
				elif position == "3":
					self.b3.setIcon(QIcon(self.nought))
					self.b3.setIconSize(QSize(55,50))
				elif position == "4": 
					self.b4.setIcon(QIcon(self.nought))
					self.b4.setIconSize(QSize(55,50))
				elif position == "5":
					self.b5.setIcon(QIcon(self.nought))
					self.b5.setIconSize(QSize(55,50))
				elif position == "6":
					self.b6.setIcon(QIcon(self.nought))
					self.b6.setIconSize(QSize(55,50))
				elif position == "7":
					self.b7.setIcon(QIcon(self.nought))
					self.b7.setIconSize(QSize(55,50))
				elif position == "8":
					self.b8.setIcon(QIcon(self.nought))
					self.b8.setIconSize(QSize(55,50))						
			else:
				#self.msg_edit.append(msg[:10])
				position = msg[-1]
				if position == "0":
					self.b0.setIcon(QIcon(self.cross))
					self.b0.setIconSize(QSize(50,50))
				elif position == "1":
					self.b1.setIcon(QIcon(self.cross))
					self.b1.setIconSize(QSize(50,50))
				elif position == "2":
					self.b2.setIcon(QIcon(self.cross))
					self.b2.setIconSize(QSize(50,50))
				elif position == "3":
					self.b3.setIcon(QIcon(self.cross))
					self.b3.setIconSize(QSize(50,50))
				elif position == "4":
					self.b4.setIcon(QIcon(self.cross))
					self.b4.setIconSize(QSize(50,50))
				elif position == "5":
					self.b5.setIcon(QIcon(self.cross))
					self.b5.setIconSize(QSize(50,50))
				elif position == "6":
					self.b6.setIcon(QIcon(self.cross))
					self.b6.setIconSize(QSize(50,50))
				elif position == "7":
					self.b7.setIcon(QIcon(self.cross))
					self.b7.setIconSize(QSize(50,50))
				elif position == "8":
					self.b8.setIcon(QIcon(self.cross))               
					self.b8.setIconSize(QSize(50,50))										
	 # Thread Slot   
	def thread_slot(self, msg):
		self.handle_gui(msg)	
		
	# Server Connector	
	def connect_to_server(self):
		mytext="Connected to a server now you can play"
		language ="en"
		
		self.voice = gTTS(text=mytext, lang=language, slow=False)
		
		self.voice.save("welcome.mp3")
		os.system("welcome.mp3")		
		self.loop_thread.connect_(self.server_edit.displayText())		#Connects to the server and instruct the user by voice that they are connected to the server
		self.loop_thread.start()
		self.mfs_edit.append("Connected to Server")
			
	def button_clicked(self):								#Exits the game
		self.close()
		
	def new_game_clicked(self):
		self.mfs_edit.clear()								# Clears out the Board
		self.b0.setIcon(QIcon(" "))
		self.b1.setIcon(QIcon(" "))
		self.b2.setIcon(QIcon(" "))
		self.b3.setIcon(QIcon(" "))
		self.b4.setIcon(QIcon(" "))
		self.b5.setIcon(QIcon(" "))
		self.b6.setIcon(QIcon(" "))
		self.b7.setIcon(QIcon(" "))
		self.b8.setIcon(QIcon(" "))
		self.loop_thread.send_message('y')
		
			
# The Main Function
def main():
	app = QApplication(sys.argv)
	widget = OXO_Client()
	widget.show()
	sys.exit(app.exec_())
main()