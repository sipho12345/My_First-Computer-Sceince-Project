import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *


class OXO_Client(QWidget):
	def __init__(self, parent=None):
		
		QWidget.__init__(self, parent)
		self.setGeometry(250, 250, 200, 150)
		self.setWindowTitle('OXO Client')
		
		 # Labels
		server_label = QLabel('Server:')    
		shape_label = QLabel('Shape:')
		mfs = QLabel('Message from the Server:')
		game_label = QLabel('The Game:')
		
		#Edits
		server_edit = QLineEdit()
		mfs_edit = QTextEdit()
		mfs_edit.move(750,450)
		
		
		#Buttons
		ng_button = QPushButton("New Game")
		self.quit = QPushButton("Quit")
		connect = QPushButton("Connect")
		
		#Buttons for the playing
		one = QPushButton("1")
		two = QPushButton("2")
		three = QPushButton("3")
		four = QPushButton("4")
		five = QPushButton("5")
		six = QPushButton("6")
		seven = QPushButton("7")
		eight = QPushButton("8")
		nine = QPushButton("9")
		
		#Picture
		pixmap = QPixmap("cross.gif")
		pic_label = QLabel()
		pic_label.setPixmap(pixmap)
		
		
		# create layout for username and password
		grid = QGridLayout()           
		grid.addWidget(server_label,0,0) 
		grid.addWidget(server_edit,0,1)   
		grid.addWidget(connect,1,1)
		grid.addWidget(shape_label,2,0)
		grid.addWidget(mfs,3,0)
		grid.addWidget(mfs_edit,4,0,3,1)
		grid.addWidget(game_label,3,1)
		grid.addWidget(ng_button,7,1)
		grid.addWidget(self.quit,7,2)
		grid.addWidget(pic_label,2,1)
		grid_widget = QWidget()
		self.setLayout(grid)
		
		
		#Game Play Box
		grid.addWidget(one,4,1)
		grid.addWidget(two,5,1)
		grid.addWidget(three,6,1)
		grid.addWidget(four,4,2)
		grid.addWidget(five,5,2)
		grid.addWidget(six,6,2)
		grid.addWidget(seven,4,3)
		grid.addWidget(eight,5,3)
		grid.addWidget(nine,6,3)
		self.quit.clicked.connect(self.button_clicked)
	def button_clicked(self):
		self.close()	
		
		
def main():
	
	app = QApplication(sys.argv)
	widget = OXO_Client()
	widget.setPalette(QPalette(QColor("red")))
	widget.setAutoFillBackground(True)
	
	widget.show()
	sys.exit(app.exec_())
main()
