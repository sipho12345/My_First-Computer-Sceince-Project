from GameClient import *

class OXOTextClient(GameClient):

    def __init__(self):
        GameClient.__init__(self)
        self.board = [' '] * BOARD_SIZE
        self.shape = None
   
        
    def clear_board(self):
        self.board = [' '] * BOARD_SIZE
        
    def input_server(self):
        return input('enter server:')
     
    def input_move(self):
        return input('enter move(0-8):')
     
    def input_play_again(self):
        return input('play again(y/n):')

    def display_board(self):
        if BOARD_SIZE== 9:
            print("[",self.board[0],"][",self.board[1],"][",self.board[2],"]\n""[",self.board[3],"][",self.board[4],"][",self.board[5],"]\n""[",self.board[6],"][",self.board[7],"][",self.board[8],"]")
    
    def handle_message(self,msg):
        
        if msg[:msg.find(",")] == "new game":
            self.display_board()
            self.shape = msg[-1]
            
            
            print('new game, Your character is', msg[-1])
            
        elif msg == 'your move':
            print('Your Move')
            self.move = self.input_move()
            self.send_message(self.move) 
         
        elif msg == 'opponents move':
            print("It's your opponents move") 
            
        elif msg[:msg.find(",")] == "valid move":
            self.shape = msg[-3]
            self.position = int(msg[-1])
            self.board[self.position]=self.shape 
            self.display_board()
            return 'valid move'
            
        elif msg == "invalid move":
            print('invalid move')
            
        elif msg[:msg.find(",")] == "game over":
            self.shape = msg[-1]
            if self.shape =='X' or self.shape == 'O': 
                print("game over, The winner is ",msg[-1])
                return self.display_board()
            
            else:                
                print('game over, Game is a tie')
                return self.display_board()
            
        elif msg == 'play again':
            self.ans= self.input_play_again()
            if self.ans == 'y': 
                self.clear_board()
            self.send_message(self.ans)
            
        elif msg == 'exit game':
            self.__del__()
            print('game ended')
    
    def play_loop(self):
        while True:
            msg = self.receive_message()
            if len(msg): self.handle_message(msg)
            else: break
            
def main():
    otc = OXOTextClient()
    
    while True:
        try:
            otc.connect_to_server(otc.input_server())
           
            break
        except:
            print('Error connecting to server!')
    otc.play_loop()
    input('Press click to exit.')
        
main()