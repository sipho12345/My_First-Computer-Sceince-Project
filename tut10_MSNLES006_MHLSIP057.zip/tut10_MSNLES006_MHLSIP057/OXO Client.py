import sys
from socket import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from LoopThread import *
from GameClient import *
from PyQt5.QtCore import *
from LoopThread import LoopThread
from GameServer import GameServer
from PyQt5.QtMultimedia import *
#from OXOTextClient import *


class OXO_Client(QWidget, GameClient):
	def __init__(self, parent=None):
		GameClient.__init__(self)
		QWidget.__init__(self, parent)
		self.setGeometry(250, 250, 200, 150)
		self.setWindowTitle('OXO Client')
		self.setToolTip('OXO Game fragment')
		
		 # Labels
		server_label = QLabel('Server:')    
		shape_label = QLabel('Shape:')
		mfs = QLabel('Message from the Server:')
		game_label = QLabel('The Game:')
		self.message = QLabel()
		position = QLabel("Positions:")
		
		#Pictures
		self.cross = QPixmap("cross.gif")
		self.nought = QPixmap("nought.gif")
		
		#Edits
		self.server_edit = QLineEdit()
		self.mfs_edit = QTextEdit()
		self.mfs_edit.move(750,450)
		
		#Buttons
		self.ng_button = QPushButton("New Game")
		self.ng_button.setToolTip("click to start a new game")
		self.quit = QPushButton("Quit")
		self.quit.setToolTip("Click to end game")
		self.connect = QPushButton("Connect")
		self.connect.setToolTip("Click to connect to with another player")
		                
		# Default Positions
		self.pixmap = QPixmap("blank.gif")
		self.p0 = QLabel()
		self.p0.setPixmap(self.pixmap)
		
		self.pixmap = QPixmap("blank.gif")
		self.p1 = QLabel()
		self.p1.setPixmap(self.pixmap)		
		
		self.pixmap = QPixmap("blank.gif")
		self.p2 = QLabel()
		self.p2.setPixmap(self.pixmap)
		
		self.pixmap = QPixmap("blank.gif")
		self.p3= QLabel()
		self.p3.setPixmap(self.pixmap)		
		
		self.pixmap = QPixmap("blank.gif")
		self.p4 = QLabel()
		self.p4.setPixmap(self.pixmap)
		
		self.pixmap = QPixmap("blank.gif")
		self.p5 = QLabel()
		self.p5.setPixmap(self.pixmap)		
		
		self.pixmap = QPixmap("blank.gif")
		self.p6 = QLabel()
		self.p6.setPixmap(self.pixmap)
		
		self.pixmap = QPixmap("blank.gif")
		self.p7= QLabel()
		self.p7.setPixmap(self.pixmap)
		
		self.pixmap = QPixmap("blank.gif")
		self.p8 = QLabel()
		self.p8.setPixmap(self.pixmap)		
		
		#Default Picture Shape 
		pixmap = QPixmap("blank.gif")
		self.pic_label = QLabel()
		self.pic_label.setPixmap(pixmap)
		
		#ComboBox
		self.combo = QComboBox()
		self.combo.addItem("0")
		self.combo.addItem("1")
		self.combo.addItem("2")
		self.combo.addItem("3")
		self.combo.addItem("4")
		self.combo.addItem("5")
		self.combo.addItem("6")
		self.combo.addItem("7")
		self.combo.addItem("8")		
		self.combo.setToolTip("Select a number <strong>here</strong> to make a move")
		
		#Grid Layout
		grid = QGridLayout() 
		grid.addWidget(self.p0,0,0)
		grid.addWidget(self.p1,0,1)
		grid.addWidget(self.p2,0,2)
		grid.addWidget(self.p3,1,0)
		grid.addWidget(self.p4,1,1)
		grid.addWidget(self.p5,1,2)
		grid.addWidget(self.p6,2,0)
		grid.addWidget(self.p7,2,1)
		grid.addWidget(self.p8,2,2)
		self.grid_widget = QWidget()
		self.grid_widget.setLayout(grid)
		self.grid_widget.setToolTip("select a number from <strong>Positions</strong> to make a move")
		
		# create layout for username and password
		grid = QGridLayout()           
		grid.addWidget(server_label,0,0) 
		grid.addWidget(self.server_edit,0,1)   
		grid.addWidget(self.connect,1,1)
		grid.addWidget(shape_label,2,0)
		grid.addWidget(mfs,3,0)
		grid.addWidget(self.mfs_edit,4,0,3,1)
		grid.addWidget(game_label,3,1)
		grid.addWidget(self.ng_button,10,1)
		grid.addWidget(self.quit,10,2)
		grid.addWidget(self.pic_label,2,1)
		grid.addWidget(self.combo,9,1)
		grid.addWidget(position,9,0)
		grid.addWidget(self.message,10,0)
		grid.addWidget(self.grid_widget,4,1)
		
		#Game Play Box
		grid_widget = QWidget()
		self.setLayout(grid)
		self.loop_thread=LoopThread()
		self.loop_thread.new_signal.connect(self.thread_slot)
		self.ng_button.clicked.connect(self.new_game_clicked)
		self.quit.clicked.connect(self.button_clicked)
		self.connect.clicked.connect(self.connect_to_server)
		#self.combo.activated.connect(self.combo_activated)
		#self.combo.activated.connect(self.p0_activated)
		#self.combo.activated.connect(self.p1_activated)
		#self.combo.activated.connect(self.p2_activated)
		#self.combo.activated.connect(self.p3_activated)
		#self.combo.activated.connect(self.p4_activated)
		#self.combo.activated.connect(self.p5_activated)
		#self.combo.activated.connect(self.p6_activated)
		#self.combo.activated.connect(self.p7_activated)
		#self.combo.activated.connect(self.p8_activated)	
		
	#def combo_activated(self):
		#text = self.combo.currentText()
		#loop_thread.send_message(text)
	#def p0_activated(self):
		#self.text = self.combo.currentText()
		#loop_thread.send_message(self.text)
	#def p1_activated(self):
		#self.text = self.combo.currentText()
		#loop_thread.send_message(self.text)
	#def p2_activated(self):
		#self.text = self.combo.currentText()
		#loop_thread.send_message(self.text)
	#def p3_activated(self):
		#self.text = self.combo.currentText()
		#loop_thread.send_message(self.text)
	#def p4_activated(self):
		#self.text = self.combo.currentText()
		#loop_thread.send_message(self.text)
	#def p5_activated(self):
		#self.text = self.combo.currentText()
		#loop_thread.send_message(self.text)
	#def p6_activated(self):
		#self.text = self.combo.currentText()
		#loop_thread.send_message(self.text)
	#def p7_activated(self):
		#self.text = self.combo.currentText()
		#loop_thread.send_message(self.text)	
	#def p8_activated(self):
		#self.text = self.combo.currentText()
		#loop_thread.send_message(self.text)	
			
	def handle_gui(self,msg):
		if msg == "new game,O":
			self.icon = self.nought
			self.pic_label.setPixmap(self.icon)
			self.mfs_edit.append(msg[:8] + "\n")
		elif msg == "new game,X":
			self.icon = self.cross
			self.pic_label.setPixmap(self.icon)
			self.mfs_edit.append(msg[:8] + "\n")      
			
		elif msg == "your move":              
			self.mfs_edit.append(msg)         
		elif msg == "opponents move":
			self.mfs_edit.append(msg)
		elif msg == "invalid move":
			self.mfs_edit.append(msg)
		elif msg[:9] == "game over":
			self.mfs_edit.append(msg[:9])
			if msg[-1] == "T":
				self.mfs_edit.append("It's a tie!")
			else:
				self.mfs_edit.append("Shape "+str(msg[-1])+" Won!")
			
		elif msg == "play again":
			self.mfs_edit.append("Press <New game> to play again and \nPress <Quit> to end game.")
		elif msg == "exit game":
			self.mfs_edit.append(msg)
		
		
		else:      
			if msg[-3] == "O":
				self.msg_edit.append(msg[:10])
				x = msg[-1]
				if x == "0":
					self.pixmap = QPixmap(self.cross)
					self.p0.setPixmap(self.pixmap)
				elif x=="1":
					self.pixmap = QPixmap(self.cross)
					self.p1.setPixmap(self.pixmap)
				elif x=="2":
					self.pixmap = QPixmap(self.cross)
					self.p2.setPixmap(self.pixmap)
				elif x=="3":
					self.pixmap = QPixmap(self.cross)
					self.p3.setPixmap(self.pixmap)	
				elif x=="4":
					self.pixmap = QPixmap(self.cross)
					self.p4.setPixmap(self.pixmap)	
				elif x=="5":
					self.pixmap = QPixmap(self.cross)
					self.p5.setPixmap(self.pixmap)	
				elif x=="6":
					self.pixmap = QPixmap(self.cross)
					self.p6.setPixmap(self.pixmap)	
				elif x=="7":
					self.pixmap = QPixmap(self.cross)
					self.p7.setPixmap(self.pixmap)
				elif x=="8":
					self.pixmap = QPixmap(self.cross)
					self.p8.setPixmap(self.pixmap)				
			else:
				self.msg_edit.append(msg[:10])
				x = msg[-1]
				if x == "0":
					self.pixmap = QPixmap(self.nought)
					self.p0.setPixmap(self.pixmap)
				elif x=="1":
					self.pixmap = QPixmap(self.nought)
					self.p1.setPixmap(self.pixmap)
				elif x=="2":
					self.pixmap = QPixmap(self.nought)
					self.p2.setPixmap(self.pixmap)
				elif x=="3":
					self.pixmap = QPixmap(self.nought)
					self.p3.setPixmap(self.pixmap)	
				elif x=="4":
					self.pixmap = QPixmap(self.nought)
					self.p4.setPixmap(self.pixmap)	
				elif x=="5":
					self.pixmap = QPixmap(self.nought)
					self.p5.setPixmap(self.pixmap)	
				elif x=="6":
					self.pixmap = QPixmap(self.nought)
					self.p6.setPixmap(self.pixmap)	
				elif x=="7":
					self.pixmap = QPixmap(self.nought)
					self.p7.setPixmap(self.pixmap)
				elif x=="8":
					self.pixmap = QPixmap(self.nought)
					self.p8.setPixmap(self.pixmap)						
	    
	def thread_slot(self, msg):								#handles signal from thread
		if msg == "invalid move":
			pass
		else:		
			self.handle_gui(msg)		
			
	def connect_to_server(self):
			self.loop_thread.connect_(self.server_edit.displayText())		#Connects to the server
			self.loop_thread.start()
			self.mfs_edit.append("Connected to Server")
			
	def button_clicked(self):								#Exits the game
		self.close()
		
	def new_game_clicked(self):
		self.mfs_edit.clear()								# Clears out the connect to Server edit box
		self.pixmap = QPixmap("blank.gif")
		self.p0 = QLabel()
		self.p0.setPixmap(self.pixmap)
		
		self.pixmap = QPixmap("blank.gif")
		self.p1 = QLabel()
		self.p1.setPixmap(self.pixmap)		
		
		self.pixmap = QPixmap("blank.gif")
		self.p2 = QLabel()
		self.p2.setPixmap(self.pixmap)
		
		self.pixmap = QPixmap("blank.gif")
		self.p3= QLabel()
		self.p3.setPixmap(self.pixmap)		
		
		self.pixmap = QPixmap("blank.gif")
		self.p4 = QLabel()
		self.p4.setPixmap(self.pixmap)
		
		self.pixmap = QPixmap("blank.gif")
		self.p5 = QLabel()
		self.p5.setPixmap(self.pixmap)		
		
		self.pixmap = QPixmap("blank.gif")
		self.p6 = QLabel()
		self.p6.setPixmap(self.pixmap)
		
		self.pixmap = QPixmap("blank.gif")
		self.p7= QLabel()
		self.p7.setPixmap(self.pixmap)
		
		self.pixmap = QPixmap("blank.gif")
		self.p8 = QLabel()
		self.p8.setPixmap(self.pixmap)
		
		
			
	
def main():
	app = QApplication(sys.argv)
	widget = OXO_Client()
	widget.setPalette(QPalette(QColor("red")))
	widget.setAutoFillBackground(True)
	widget.show()
	sys.exit(app.exec_())
main()